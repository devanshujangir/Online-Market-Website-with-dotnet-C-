﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserDetailsEdit : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"]==null)
        {
            Response.Redirect("~/login.aspx");
        }
        string email = Session["email"].ToString();
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(email));
        firstName.Text = userExits.FirstName;
        lastName.Text = userExits.LastName;
        emailId.Text = userExits.Email;
        phone.Text = userExits.Phone;
        address.Text = userExits.ShippingAddress;
        pinCode.Text = userExits.PinCode;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string email = emailId.Text;
        userTable ptable = (from c in cn.userTables where c.Email == email select c).FirstOrDefault();
        ptable.FirstName = firstName.Text;
        ptable.LastName = lastName.Text;
        ptable.Phone = phone.Text;
        ptable.PinCode = pinCode.Text;
        ptable.ShippingAddress = address.Text;
        cn.SaveChanges();
        Label9.Text = "Data Update successfully...";
      //  Response.Redirect("~/home.aspx");
    }
}