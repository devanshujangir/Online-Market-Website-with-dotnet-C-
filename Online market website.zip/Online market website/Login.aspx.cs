﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        error1.Text = "You must login for if you want Buy something";
    }
  

    protected void login_Click(object sender, EventArgs e)
    {
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(username.Text));
        if (userExits!=null)
        {
            if (userExits.Password.Equals(password.Text))
            {
                Session["email"] = userExits.Email.ToString();
                Response.Redirect("~/Home.aspx");
            }
            else
            {
                error.Text = "Password incorrect";
            }
        }
        else
        {
            error.Text = "User not found";
        }
    }
}