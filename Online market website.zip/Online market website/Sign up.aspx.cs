﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void login_Click(object sender, EventArgs e)
    {
       
    }

    protected void signup_Click(object sender, EventArgs e)
    {
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(email.Text));
        if (password.Text==passwordRetype.Text)
        {
            if (userExits == null)
            {
                var bind = new userTable {ShippingAddress="NULL" ,PinCode="NULL", FirstName = firstName.Text, LastName = lastName.Text, Email = email.Text, Password = password.Text, Phone = phone.Text };
                cn.userTables.Add(bind);
                cn.SaveChanges();
                error.Text = "Account successfully created";
            }
            else
            {
                error.Text = "Entered email address is already taken";
            }
        }
        else
        {
                error.Text = "Retype password is not match";
        }
        

    }
}