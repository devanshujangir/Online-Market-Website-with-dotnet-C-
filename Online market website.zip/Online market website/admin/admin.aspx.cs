﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_admin : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            GridView4.Visible = false;
        }
        var bind = cn.productTables.ToList();
        GridView4.DataSource = bind;
        GridView4.DataBind();
        if (Session["adminEmail"]==null)
        {
            Response.Redirect("~/admin/admin login.aspx");
        }
        else
        {
            name.Text = Session["adminEmail"].ToString();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile && pname.Text!=string.Empty && pcat.Text!=string.Empty &&pprice.Text!=string.Empty && pavail.Text!=string.Empty)
        {
            var userExits = cn.productTables.FirstOrDefault(a => a.ProductName.Equals(pname.Text));
            if (userExits==null)
            {
                byte[] file = ReadStream(FileUpload1.PostedFile.InputStream);
                var add = new productTable { ProductName = pname.Text, AvaliableProduct = Convert.ToInt32(pavail.Text), ProductCategory = pcat.Text, ProductPrice = Convert.ToInt32(pprice.Text), ProductPhoto = file };
                cn.productTables.Add(add);
                cn.SaveChanges();
                error.Text = "Data added";
                pname.Text = "";
                pprice.Text = "";
                pavail.Text = "";
                pcat.Text = "";
            }
            else
            {
                pname.Text = "";
                pprice.Text = "";
                pavail.Text = "";
                pcat.Text = "";
                error.Text = "Product is already exits";
            }
           
        }
        else
        {
            error.Text = "Fill all fields & Please upload image first";
        }
    }
    public static byte[] ReadStream(Stream input)
    {
        byte[] buffer = new byte[16 * 1024];
        using (MemoryStream ms = new MemoryStream())
        {
            int read;
            while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                ms.Write(buffer, 0, read);
            }
            return ms.ToArray();
        }
    }



    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {
        if (Menu1.SelectedItem.Value=="Add Product")
        {
            MultiView1.ActiveViewIndex = 0;
        }
        if (Menu1.SelectedItem.Value == "View All Product")
        {
            MultiView1.ActiveViewIndex = 1;
        }
        if (Menu1.SelectedItem.Value=="View Product By Category")
        {
            MultiView1.ActiveViewIndex = 2;
        }
        if (Menu1.SelectedItem.Value == "Edit/Delete Product")
        {
            //MultiView1.ActiveViewIndex = 4;
            Response.Redirect("~/admin/edititems.aspx");
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("~/home.aspx");
    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        string search = GridView2.SelectedRow.Cells[0].Text;
        Session["s1"] = search.ToString();
        MultiView1.ActiveViewIndex = 3;
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        //MultiView1.ActiveViewIndex = 4;
        // GridView4.Visible = true;
        Response.Redirect("~/admin/edititems.aspx");
    }

    protected void GridView4_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {

    }

    protected void GridView4_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }

    protected void GridView4_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView4.EditIndex = e.NewEditIndex;
    }

    protected void GridView4_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
}