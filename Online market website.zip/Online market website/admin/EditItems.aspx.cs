﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_EditItems : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminEmail"] == null)
        {
            Response.Redirect("~/admin/admin login.aspx");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        var bind = cn.productTables.ToList();
        GridView4.DataSource = bind;
        GridView4.DataBind();
    }

    protected void GridView4_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView4.EditIndex = -1;
        var bind = cn.productTables.ToList();
        GridView4.DataSource = bind;
        GridView4.DataBind();
    }

    protected void GridView4_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow row = GridView4.Rows[e.RowIndex];
        //int pid = Convert.ToInt32(GridView4.DataKeys[e.RowIndex].Values[0]);
        int pids =Convert.ToInt32( (row.FindControl("pid") as Label).Text);
        productTable ptable = (from c in cn.productTables where c.ProductId == pids select c).FirstOrDefault();
        cn.productTables.Remove(ptable);
        cn.SaveChanges();
        var bind = cn.productTables.ToList();
        GridView4.DataSource = bind;
        GridView4.DataBind();
    }

    protected void GridView4_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView4.EditIndex = e.NewEditIndex;
        var bind = cn.productTables.ToList();
        GridView4.DataSource = bind;
        GridView4.DataBind();
    }

    protected void GridView4_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GridView4.Rows[e.RowIndex];
        int pid = Convert.ToInt32((row.FindControl("pid") as Label).Text);
        string pname = (row.FindControl("pids") as TextBox).Text;
        string pprice = (row.FindControl("pprices") as TextBox).Text;
        string pavail = (row.FindControl("pavails") as TextBox).Text;
        string pcat = (row.FindControl("pcats") as TextBox).Text;
        productTable ptable = (from c in cn.productTables where c.ProductId == pid select c).FirstOrDefault();
        ptable.ProductName = pname;
        ptable.ProductPrice = Convert.ToInt32(pprice);
        ptable.AvaliableProduct = Convert.ToInt32(pavail);
        ptable.ProductCategory = pcat;
        cn.SaveChanges();
        GridView4.EditIndex = -1;
        var bind = cn.productTables.ToList();
        GridView4.DataSource = bind;
        GridView4.DataBind();


    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/admin/admin.aspx");
    }
}