﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            userEmails.Text = "Guest";
            signup.Visible = true;
            login.Visible = true;

        }
        else
        {
            userEmails.Text = Session["email"].ToString();
            signup.Visible = false;
            login.Visible = false;

        }
    }

    protected void logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("~/home.aspx");
    }
}