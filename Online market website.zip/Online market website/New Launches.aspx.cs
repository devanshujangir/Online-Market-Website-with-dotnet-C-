﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class New_Launches : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public static byte[] ReadStream(Stream input)
    {
        byte[] buffer = new byte[16 * 1024];
        using (MemoryStream ms = new MemoryStream())
        {
            int read;
            while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                ms.Write(buffer, 0, read);
            }
            return ms.ToArray();
        }
    }





    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

        //Label pname = new Label();
        //Label pprice = new Label();
        //Label quantity = new Label();
        //Label status = new Label();
        //pname.Text = GridView1.SelectedRow.Cells[2].Text;
        //pprice.Text = GridView1.SelectedRow.Cells[3].Text;
        if (Session["email"] == null)
        {
            Response.Redirect("~/login.aspx");
        }
        else
        {
            string email1 = Session["email"].ToString();
            var test = cn.userTables.FirstOrDefault(a => a.Email.Equals(email1));
            string ShippingAddress = test.ShippingAddress;
            int quantity = 1;
            string pid = GridView1.SelectedRow.Cells[0].Text;
            int b = Convert.ToInt32(pid);
            var userExits = cn.productTables.FirstOrDefault(a => a.ProductId.Equals(b));
            string pname = GridView1.SelectedRow.Cells[1].Text;
            var exits = cn.eCartTables.FirstOrDefault(a => a.ProductName.Equals(pname));
            if (exits == null)
            {
                var bind = new eCartTable { ProductQuantity = Convert.ToString(quantity), ShippingAddress = ShippingAddress, BuyStatus = "Panding", CustmerEmail = Session["email"].ToString(), ProductImage = userExits.ProductPhoto, ProductName = userExits.ProductName, ProductPrice = Convert.ToInt32(userExits.ProductPrice) };
                cn.eCartTables.Add(bind);
                cn.SaveChangesAsync();
            }
            if (exits != null)
            {
                string email = Session["email"].ToString();
                string qua = GridView1.SelectedRow.Cells[1].Text;
                var ecart = cn.eCartTables.FirstOrDefault(a => a.ProductName.Equals(qua));
                int q = Convert.ToInt32(ecart.ProductQuantity);
                eCartTable add = (from c in cn.eCartTables where c.CustmerEmail == email select c).FirstOrDefault();
                add.ProductQuantity = Convert.ToString(q + 1);
                cn.SaveChanges();
            }

        }
    }
}