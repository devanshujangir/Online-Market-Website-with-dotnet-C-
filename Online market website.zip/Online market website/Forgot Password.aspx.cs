﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Forgot_Password : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void submit_Click(object sender, EventArgs e)
    {
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(username.Text));
        if (userExits!=null)
        {
            newPassword.Visible = true;
            retypePassword.Visible = true;
            changePassword.Visible = true;
            error1.Text = "";
            username.Enabled = false;

        }
        else
        {
            error1.Text = "Entered email is not Exits...";
        }
    }

    protected void changePassword_Click(object sender, EventArgs e)
    {
        if (newPassword.Text == retypePassword.Text)
        {
            var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(username.Text));
            string email = username.Text.ToString();
            userTable add = (from c in cn.userTables where c.Email == email select c).FirstOrDefault();
            add.Password = newPassword.Text;
            cn.SaveChanges();
            error2.Text = "Password successfully changed, Go to login page.";
        }
        else
        {
            error2.Text = "Both Password fields are not same";
        }
    }
}