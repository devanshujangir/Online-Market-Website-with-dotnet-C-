﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage2 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"]!=null)
        {
            ImageButton4.Visible = false;
            ImageButton5.Visible = false;
            welcome.Visible= true;
            Email.Text = Session["email"].ToString();
            adminlogin.Visible = false;
            Button2.Visible = true;
        }
        else
        {
            
            Button1.Visible = false;
            adminlogin.Visible = true;
            welcome.Visible = false;
            ImageButton4.Visible = true;
            ImageButton5.Visible = true;
        }
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/login.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/sign up.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("~/home.aspx");
    }

    protected void adminlogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/admin/admin login.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/ecart.aspx");
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        string search = TextBox1.Text;
        Response.Redirect("~/searchitems?search="+search);
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/New Launches.aspx");
    }

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/ShopByCateogory.aspx");
    }

    protected void ImageButton7_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/home.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/editProfile.aspx");
    }
}
