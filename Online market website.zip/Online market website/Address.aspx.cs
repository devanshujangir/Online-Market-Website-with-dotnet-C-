﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Address : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        string email = Session["email"].ToString();
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(email));
        TextBox2.Text = userExits.ShippingAddress;
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/paymentpage.aspx");
    }
}