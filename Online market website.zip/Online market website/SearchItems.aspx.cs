﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchItems : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["search"] == null)
        {
            Label1.Text = "Type and search the products";
        }
        else
        {
            Label1.Text = "We have following products regarding your search..";
        }
    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Label pname = new Label();
        //Label pprice = new Label();
        //Label quantity = new Label();
        //Label status = new Label();
        //pname.Text = GridView1.SelectedRow.Cells[2].Text;
        //pprice.Text = GridView1.SelectedRow.Cells[3].Text;
        if (Session["email"] == null)
        {
            Response.Redirect("~/login.aspx");
        }
        else
        {
            string email = Session["email"].ToString();
            var test = cn.userTables.FirstOrDefault(a => a.Email.Equals(email));
            string ShippingAddress = test.ShippingAddress;
            string pid = GridView1.SelectedRow.Cells[0].Text;
            int b = Convert.ToInt32(pid);
            var userExits = cn.productTables.FirstOrDefault(a => a.ProductId.Equals(b));
            var bind = new eCartTable { BuyStatus = "Pending",ShippingAddress=ShippingAddress, ProductQuantity="1", CustmerEmail = Session["email"].ToString(), ProductImage = userExits.ProductPhoto, ProductName = userExits.ProductName, ProductPrice = Convert.ToInt32(userExits.ProductPrice) };
            cn.eCartTables.Add(bind);
            cn.SaveChangesAsync();
        }
    }

    protected void shopNow_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/home.aspx");
    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("~/login.aspx");
        }
        else
        {
            string email = Session["email"].ToString();
            var test = cn.userTables.FirstOrDefault(a => a.Email.Equals(email));
            string ShippingAddress = test.ShippingAddress;
            string pid = GridView2.SelectedRow.Cells[0].Text;
            int b = Convert.ToInt32(pid);
            var userExits = cn.productTables.FirstOrDefault(a => a.ProductId.Equals(b));
            var bind = new eCartTable { BuyStatus = "Panding", ProductQuantity = "1", ShippingAddress = ShippingAddress, CustmerEmail = Session["email"].ToString(), ProductImage = userExits.ProductPhoto, ProductName = userExits.ProductName, ProductPrice = Convert.ToInt32(userExits.ProductPrice) };
            cn.eCartTables.Add(bind);
            cn.SaveChangesAsync();
        }
    }
}