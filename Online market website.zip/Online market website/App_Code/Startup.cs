﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Online_market_website.Startup))]
namespace Online_market_website
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
