﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PaymentPage : System.Web.UI.Page
{
    DatabaseEntities en = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void PayNow_Click(object sender, EventArgs e)
    {
        string userEmail = Session["email"].ToString();
        eCartTable ptable = (from c in en.eCartTables where c.CustmerEmail == userEmail select c).FirstOrDefault();
        ptable.CardHolderName = name.Text;
        ptable.CardNo = cardNo.Text;
        ptable.CardExpiry = date.Text;
        ptable.CardCVV = cvv.Text;
        ptable.BuyStatus = "Successful";
        en.SaveChanges();
        string pname = Session["pname"].ToString();
        var userExits = en.productTables.FirstOrDefault(a => a.ProductName.Equals(pname));
        int avail = userExits.AvaliableProduct;
        int updateAvail = avail - 1;
        productTable etable = (from c in en.productTables where c.ProductName == pname select c).FirstOrDefault();
        etable.AvaliableProduct = updateAvail;
        en.SaveChanges();
        error.Text = "Your payment is confirmed successfully...";

    }
}