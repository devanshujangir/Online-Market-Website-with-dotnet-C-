﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class eCart : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"]==null)
        {
            Response.Redirect("~/login.aspx");
        }
        
    }


    protected void shopNow_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/home.aspx");
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int pid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
        eCartTable cart = (from c in cn.eCartTables where c.Id == pid select c).FirstOrDefault();
        cn.eCartTables.Remove(cart);
        cn.SaveChanges();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string pname = GridView1.SelectedRow.Cells[2].Text;
        Session["pname"] = pname;
         Response.Redirect("~/paymentpage.aspx");
       // Response.Redirect("~/editProfile");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/editProfile");
    }
}