﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class editProfile : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
       
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {

    }

    protected void Button3_Click1(object sender, EventArgs e)
    {
        //var bind = cn.userTables.Where(a => a.Email.Equals(Session["email"].ToString().ToList()));
        var bnd = cn.userTables.ToList().Where(a => a.Email.Equals(Session["email"].ToString()));
        GridView2.DataSource = bnd;
        GridView2.DataBind();
    }

    protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView2.EditIndex = e.NewEditIndex;
        var bnd = cn.userTables.ToList().Where(a => a.Email.Equals(Session["email"].ToString()));
        GridView2.DataSource = bnd;
        GridView2.DataBind();
    }

    protected void GridView2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView2.EditIndex = -1;
        var bnd = cn.userTables.ToList().Where(a => a.Email.Equals(Session["email"].ToString()));
        GridView2.DataSource = bnd;
        GridView2.DataBind();
    }

    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GridView2.Rows[e.RowIndex];
        string email = Session["email"].ToString();
        string pname = (row.FindControl("fnames") as TextBox).Text;
        string pprice = (row.FindControl("lnames") as TextBox).Text;
        string pavail = (row.FindControl("passs") as TextBox).Text;
        string pcat = (row.FindControl("emails") as TextBox).Text;
        string phone = (row.FindControl("phones") as TextBox).Text;
        string address = (row.FindControl("addresss") as TextBox).Text;
        string pin = (row.FindControl("pins") as TextBox).Text;
        userTable ptable = (from c in cn.userTables where c.Email == email select c).FirstOrDefault();
        ptable.FirstName = pname;
        ptable.LastName = pprice;
        ptable.Password = pavail;
        ptable.Email = pcat;
        ptable.Phone = phone;
        ptable.ShippingAddress = address;
        ptable.PinCode = pin;
        cn.SaveChanges();
        GridView2.EditIndex = -1;
        var bnd = cn.userTables.ToList().Where(a => a.Email.Equals(Session["email"].ToString()));
        GridView2.DataSource = bnd;
        GridView2.DataBind();
    }
}